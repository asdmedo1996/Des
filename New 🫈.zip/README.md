# 📱 تطبيق إدارة المحافظ الإلكترونية في مصر (Egypt Wallets Manager)

تطبيق أندرويد عصري مبني بلغة **Kotlin** وواجهة **Jetpack Compose** لإدارة وتتبع أرصدة ومعاملات جميع المحافظ الإلكترونية في مصر (InstaPay, Vodafone Cash, Orange Cash, Etisalat Cash, WE Cash).

## ✨ المميزات
- **عرض إجمالي السيولة:** تجميع أرصدة كافة المحافظ في شاشة واحدة.
- **حاسبة الرسوم الذكية:** حساب رسوم التحويل والسحب النقدي من الـ ATM بدقة.
- **سجل المعاملات:** متابعة كافة الحركات المالية (تحويل، سحب، دفع فواتير).
- **ربط API متكامل:** مبني باستخدام `Retrofit2` و `Coroutines` مع نظام Fallback للبيانات التجريبية.

## 🛠 التقنيات المستخدمة
- **Kotlin** & **Coroutines**
- **Jetpack Compose (Material 3)**
- **Navigation Compose**
- **Retrofit2 & OkHttp3**
- **Clean Architecture / Repository Pattern**
