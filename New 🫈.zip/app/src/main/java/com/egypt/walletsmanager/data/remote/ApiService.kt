package com.egypt.walletsmanager.data.remote

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Header
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor

data class WalletApiResponse(
    val status: Boolean,
    val message: String,
    val data: List<RemoteWalletDto>?
)

data class RemoteWalletDto(
    val id: String,
    val walletName: String,
    val phoneNumber: String,
    val balance: Double,
    val providerType: String
)

data class TransactionDto(
    val id: String,
    val title: String,
    val amount: Double,
    val date: String,
    val type: String
)

data class TransactionsResponse(
    val status: Boolean,
    val message: String,
    val data: List<TransactionDto>?
)

interface ApiService {
    @GET("api/v1/wallets")
    suspend fun getUserWallets(
        @Header("Authorization") token: String
    ): WalletApiResponse

    @GET("api/v1/transactions")
    suspend fun getTransactions(
        @Header("Authorization") token: String
    ): TransactionsResponse
}

object RetrofitClient {
    private const val BASE_URL = "https://api.egypt-wallets-manager.com/"

    private val client = OkHttpClient.Builder()
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        })
        .build()

    val apiService: ApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }
}
