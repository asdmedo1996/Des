package com.egypt.walletsmanager.presentation.calculator

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalculatorScreen() {
    var amountText by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf("تحويل لنفس الشبكة") }

    val amount = amountText.toDoubleOrNull() ?: 0.0
    
    val fee = when (selectedType) {
        "تحويل لنفس الشبكة" -> 1.0
        "تحويل لشبكة أخرى" -> amount * 0.005
        "سحب نقدى من ماكينة ATM" -> amount * 0.02
        else -> 0.0
    }
    
    val netAmount = if (selectedType == "سحب نقدى من ماكينة ATM") amount + fee else amount - fee

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("حاسبة الرسوم والمعاملات", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = amountText,
            onValueChange = { amountText = it },
            label = { Text("المبلغ بالمصري (ج.م)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))
        Text("نوع المعاملة:", fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))

        val options = listOf("تحويل لنفس الشبكة", "تحويل لشبكة أخرى", "سحب نقدى من ماكينة ATM")
        options.forEach { option ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
            ) {
                RadioButton(
                    selected = selectedType == option,
                    onClick = { selectedType = option }
                )
                Text(text = option, modifier = Modifier.padding(start = 8.dp))
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("تفاصيل الحساب:", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Text("قيمة الرسوم المحسوبة: $fee ج.م")
                Spacer(modifier = Modifier.height(4.dp))
                Text("المبلغ الإجمالي بعد المعاملة: $netAmount ج.م", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}
