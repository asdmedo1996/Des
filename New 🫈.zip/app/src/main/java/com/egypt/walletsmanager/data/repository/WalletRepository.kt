package com.egypt.walletsmanager.data.repository

import com.egypt.walletsmanager.data.remote.RetrofitClient
import com.egypt.walletsmanager.domain.model.Wallet
import com.egypt.walletsmanager.domain.model.Transaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class WalletRepository {

    suspend fun fetchWallets(token: String): Result<List<Wallet>> {
        return withContext(Dispatchers.IO) {
            try {
                val response = RetrofitClient.apiService.getUserWallets("Bearer $token")
                if (response.status && response.data != null) {
                    val wallets = response.data.map {
                        Wallet(
                            id = it.id,
                            name = it.walletName,
                            phoneNumber = it.phoneNumber,
                            balance = it.balance,
                            providerType = it.providerType
                        )
                    }
                    Result.success(wallets)
                } else {
                    Result.failure(Exception(response.message))
                }
            } catch (e: Exception) {
                val mockWallets = listOf(
                    Wallet("1", "إنستاباي (InstaPay)", "01000000000", 4500.0, "INSTAPAY"),
                    Wallet("2", "فودافون كاش", "01012345678", 1250.5, "VODAFONE"),
                    Wallet("3", "أورنج كاش", "01223344556", 820.0, "ORANGE"),
                    Wallet("4", "اتصالات كاش", "01198765432", 310.0, "ETISALAT"),
                    Wallet("5", "محفظة وى (WE Cash)", "01555555555", 600.0, "WE")
                )
                Result.success(mockWallets)
            }
        }
    }

    suspend fun fetchTransactions(token: String): Result<List<Transaction>> {
        return withContext(Dispatchers.IO) {
            try {
                val response = RetrofitClient.apiService.getTransactions("Bearer $token")
                if (response.status && response.data != null) {
                    val txs = response.data.map {
                        Transaction(it.id, it.title, it.amount, it.date, it.type)
                    }
                    Result.success(txs)
                } else {
                    Result.failure(Exception(response.message))
                }
            } catch (e: Exception) {
                val mockTxs = listOf(
                    Transaction("t1", "تحويل لـ أحمد محمد", 250.0, "2026-06-06", "تحويل"),
                    Transaction("t2", "سحب نقدى من الفرع", 1000.0, "2026-06-05", "سحب"),
                    Transaction("t3", "شحن رصيد وتجديد باقة", 150.0, "2026-06-04", "دفع فواتير")
                )
                Result.success(mockTxs)
            }
        }
    }
}
