package com.egypt.walletsmanager.presentation.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.egypt.walletsmanager.presentation.calculator.CalculatorScreen
import com.egypt.walletsmanager.presentation.home.HomeScreen
import com.egypt.walletsmanager.presentation.transactions.TransactionsScreen

sealed class Screen(val route: String, val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    object Home : Screen("home", "المحافظ", Icons.Default.Home)
    object Calculator : Screen("calculator", "حاسبة الرسوم", Icons.Default.Menu)
    object Transactions : Screen("transactions", "المعاملات", Icons.Default.List)
}

@Composable
fun MainAppContainer() {
    val navController = rememberNavController()
    val items = listOf(Screen.Home, Screen.Calculator, Screen.Transactions)

    Scaffold(
        bottomBar = {
            NavigationBar {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route

                items.forEach { screen ->
                    NavigationBarItem(
                        icon = { Icon(screen.icon, contentDescription = screen.title) },
                        label = { Text(screen.title) },
                        selected = currentRoute == screen.route,
                        onClick = {
                            if (currentRoute != screen.route) {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.route) { HomeScreen() }
            composable(Screen.Calculator.route) { CalculatorScreen() }
            composable(Screen.Transactions.route) { TransactionsScreen() }
        }
    }
}
