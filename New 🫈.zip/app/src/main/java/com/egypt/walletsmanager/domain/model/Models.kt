package com.egypt.walletsmanager.domain.model

data class Wallet(
    val id: String,
    val name: String,
    val phoneNumber: String,
    val balance: Double,
    val providerType: String
)

data class Transaction(
    val id: String,
    val title: String,
    val amount: Double,
    val date: String,
    val type: String
)
